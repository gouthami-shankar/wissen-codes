package Singleton;

public class Parent {
    private static Parent parent;
    protected Parent() {
    }
    public static synchronized Parent getInstance() throws Exception {
        if (parent == null) {
            parent = new Parent();
        }
        return parent;
    }
    public void display(){
        System.out.println("Welcome to parent class");
    }
}
