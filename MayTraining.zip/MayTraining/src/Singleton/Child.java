package Singleton;

public class Child extends Parent {
    private static Child child;
    private Child(){
    }
    public static synchronized Child getInstance() throws Exception {
        if (child == null) {
            child = new Child();
        }
        return child;
    }
    public void display(){
        System.out.println("Welcome to child class");
    }
}
