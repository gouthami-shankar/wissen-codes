package Singleton;

import Singleton.Child;
import Singleton.Parent;

public class Runner {
    public static void main(String[] args) throws Exception {
        Parent parent = Parent.getInstance();
        System.out.println(parent);
        parent.display();
        Parent child = Child.getInstance();
        System.out.println(child);
        child.display();
        Parent parent1 = Parent.getInstance();
        parent1.display();
        System.out.println(parent1);
        Parent child1 = Child.getInstance();
        System.out.println(child1);
    }

}
