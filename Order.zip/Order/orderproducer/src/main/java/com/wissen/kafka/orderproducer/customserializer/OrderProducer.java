package com.wissen.kafka.orderproducer.customserializer;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

public class OrderProducer {

	public static void main(String[] args) 
	{
		Properties prop = new Properties();
		prop.setProperty("bootstrap.servers", "localhost:9092");
		prop.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		prop.setProperty("value.serializer", "com.wissen.kafka.orderproducer.customserializer.OrderSerializer");
		
		KafkaProducer<String, Order> producer = new KafkaProducer<String, Order>(prop);
		Order order = new Order();
		order.setCustomername("Gouthami");
		order.setProduct("DELL");
		order.setQuantity(3);
		ProducerRecord<String, Order> record = new ProducerRecord<>("OrderSerDeserTopic", order.getCustomername(), order);
		
		try 
		{
			producer.send(record);
			System.out.println("Message sent Successully");
		
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		finally {
			producer.close();
		}
	}

}


