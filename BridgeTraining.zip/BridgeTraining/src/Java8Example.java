import com.sun.org.apache.xpath.internal.operations.Bool;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;


class Emp{
    private String empName;
    private int age;
    private double salary;
    private String designation;

    public Emp() {
        super();
    }

    public Emp(String empName, int age, double salary, String designation) {
        this.empName = empName;
        this.age = age;
        this.salary = salary;
        this.designation = designation;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "empName='" + empName + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                ", designation='" + designation + '\'' +
                '}';
    }
}


public class Java8Example {
    public static void main(String[] args) {
        List<Emp> employees= new ArrayList<>();
        employees.add(new Emp("Mona",22,25000,"Tester"));
        employees.add(new Emp("Cocco",25,65000,"Programmer"));
        employees.add(new Emp("Pooh Winnie",35,98000,"Manager"));
        employees.add(new Emp("MiniMouse",53,89900,"Manager"));
        employees.add(new Emp("MickeyMouse",32,56000,"Tester"));
        employees.add(new Emp("Donald Duck",42,78000,"Programmer"));

        System.out.println("Count of employee");
        Map<String,Long> result= employees.stream().collect(Collectors.groupingBy(e->e.getDesignation(),Collectors.counting()));
        System.out.println(result);

        System.out.println("Grouping the employee wrt designation");
        Map<String,List<String>> answer= employees.stream().collect(Collectors.groupingBy(e->e.getDesignation(),Collectors.mapping(e->e.getEmpName().toUpperCase(),Collectors.toList())));
        System.out.println(answer);

        System.out.println("Grouping by salary");
        Map<String,Integer> result1= employees.stream().collect(Collectors.groupingBy(e->e.getDesignation(), Collectors.summingInt(e-> (int) e.getSalary())));
        System.out.println(result1);

        System.out.println("Partioning based on age");
        Map<Boolean,List<Emp>> result2= employees.stream().collect(Collectors.partitioningBy(e->e.getAge()>30));
        System.out.println(result2);

        System.out.println("Partioning based on Designation");
        Map<Boolean,List<Emp>> result3= employees.stream().collect(Collectors.partitioningBy(e->e.getDesignation()=="Tester"));
        System.out.println(result3);

        System.out.println("Grouping by designation");
        Map<String, List<Emp>> result4= employees.stream().collect(Collectors.groupingBy(e->e.getDesignation()));
        System.out.println(result4);
    }
}
