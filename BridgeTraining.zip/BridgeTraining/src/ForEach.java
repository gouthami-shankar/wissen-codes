import java.util.Enumeration;
import java.util.Vector;
import java.util.function.Consumer;

public class ForEach {
    public static void main(String[] args) {
        // Vector is used in multithread environment. For executing one by one task vector is used. It is syncronished
        Vector list = new Vector();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(6);
        Enumeration e = list.elements();
        while (e.hasMoreElements()) {
            System.out.println(e.nextElement());
        }
        Consumer<Integer>c1= (x)-> System.out.println(x);
        list.forEach(c1);

       list.forEach(System.out::println);

       list.forEach((x)-> System.out.println(x));
    }
}
