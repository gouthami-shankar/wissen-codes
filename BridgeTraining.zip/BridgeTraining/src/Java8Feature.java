import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@FunctionalInterface
interface EmployeeSalaryCount {
    static int calculate(List<Employee> employee) {
        int sum = employee.stream().reduce(0, (a, b) -> a + (int) b.getSalary(), Integer::sum);
        return sum;
    }
    List<Employee> filterAdult(List<Employee> employee);
}

 class Employee {
    private int employeeId;
    private String employeeName;
    private int age;
    private double salary;

    public Employee() {
        super();
        // TODO Auto-generated constructor stub
    }
    public Employee(int employeeId, String employeeName, int age, double salary) {
        super();
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.age = age;
        this.salary = salary;
    }
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "employeeId=" + employeeId + "\n" + "employeeName=" + employeeName + "\n" + "age=" + age + "\n" + "salary=" + salary + "\n" + "--------------------\n";
    }

}

class Java8Features implements EmployeeSalaryCount {
    public static void main(String[] args) {
        Java8Features obj = new Java8Features();
        List<Employee> employee = new LinkedList<>();
        employee.add(new Employee(3, "Gouthami", 24, 1100));
        employee.add(new Employee(1, "Kiran", 34, 7000));
        employee.add(new Employee(5, "Aura", 14, 1500));
        employee.add(new Employee(2, "Vamshi", 34, 2000));
        employee.add(new Employee(4, "Keerthi", 22, 900));

        /*
         * Used when functional interface is not implemented to class and done using
         * lambda expression
         */
        System.out.println("Filter Age");
        EmployeeSalaryCount filterAge = (age) -> {
            List<Employee> employeeAge = age.stream().filter(emp -> emp.getAge() > 20).collect(Collectors.toList());
            return employeeAge;
        };
        System.out.println(filterAge.filterAdult(employee));
        System.out.println("======================================");

        /* Static method calling */
        System.out.println("Static Method Calling");
        int sum = EmployeeSalaryCount.calculate(employee);
        System.out.println(sum);
        System.out.println("======================================");

        /* Used when functional interface is implemented to class */
        System.out.println("Functional Interface when implemented to class");
        List<Employee> employeeList = obj.filterAdult(employee);
        employeeList.forEach(System.out::println);
        System.out.println("======================================");

        /* Map function */
        System.out.println("Map Function");
        List<Employee> convertEmployeeToAdult = employee.stream().map(emp -> convertEmployeeToAdult(emp)).collect(Collectors.toList());
        convertEmployeeToAdult.forEach(System.out::println);

        System.out.println("Convert to upper case using map");
        List<String> convertEmployeeNameToUpperCase = employee.stream().map(emp -> emp.getEmployeeName().toUpperCase()).collect(Collectors.toList());
        System.out.println(convertEmployeeNameToUpperCase);
        System.out.println("======================================");

        /* Optional Feature */
        System.out.println("Optional Feature");
        Optional<Employee> optionalEmployee = Optional.of(new Employee(15, "Siya", 90, 900));
        try {
            optionalEmployee.filter(emp -> emp.getAge() < 60).orElseThrow(() -> new InvalidAgeException("Age should be below 60"));
            System.out.println(optionalEmployee);
        } catch (InvalidAgeException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("======================================");

        // sequential stream
        System.out.println("Sequential Stream");
        Stream<Employee> sequentialStream = employee.stream();
        System.out.println("High Nums sequential");
        Stream<Employee> highNumsSeq = sequentialStream.filter(p -> p.getEmployeeId() > 1);
        highNumsSeq.forEach(p -> System.out.println(p));
        System.out.println("======================================");

        // parallel stream
        System.out.println("Parallel Stream");
        Stream<Employee> parallelStream = employee.parallelStream();
        System.out.println("High Nums parallel");
        Stream<Employee> highNums = parallelStream.filter(p -> p.getEmployeeId() > 1);
        highNums.forEach(p -> System.out.println(p));
        System.out.println("======================================");

        Map<String, List<Employee>> employeeMap = new HashMap<>();

        /* Iteration on map using lambda expression */
        System.out.println("Iteration on map using lambda expression");
        employeeMap.put("Map Employee", employee);
        Map<String, List<Employee>> result = employeeMap.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue().stream().filter(i -> i.getAge() > 24).map(emp -> convertEmployeeToAdult(emp)).collect(Collectors.toList())));
        System.out.println(result);

        System.out.println("Reverse");
        employee.sort(Comparator.comparing(Employee::getSalary).reversed());
        System.out.println(employee);

        System.out.println("Two value comparing");
        employee.sort(Comparator.comparing(Employee::getAge).reversed().thenComparing(Employee::getEmployeeName));
        System.out.println(employee);

        System.out.println("Comparator java 8");
        Comparator<Employee> cmp = (i1, i2) -> i1.getAge() - i2.getAge();
        employee.sort(cmp);
        System.out.println(employee);


    }

    public static Employee convertEmployeeToAdult(Employee employee) {
        if (employee.getAge() == 14) {
            employee.setAge(23);
        }
        return employee;
    }

    @Override
    public List<Employee> filterAdult(List<Employee> employee) {
        List<Employee> filteredEmployeeBasedOnAge = employee.stream().filter(emp -> emp.getAge() > 23).collect(Collectors.toList());
//		filteredEmployeeBasedOnAge.forEach(age -> System.out.println(age));
//		filteredEmployeeBasedOnAge.forEach(System.out::println);
        return filteredEmployeeBasedOnAge;
    }
}

class InvalidAgeException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public InvalidAgeException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public InvalidAgeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        // TODO Auto-generated constructor stub
    }

    public InvalidAgeException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public InvalidAgeException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public InvalidAgeException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }


}
