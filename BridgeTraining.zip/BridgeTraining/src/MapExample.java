import java.util.HashMap;
import java.util.Map;

public class MapExample {
    public static void main(String[] args) {
        Map<Integer,String> map=new HashMap<>();
        map.put(11,"Ramesh");
        map.put(22,"Suresh");
        map.put(33,"Dinesh");
        map.put(44,"Mahesh");
        map.put(55,"Ganesh");

        map.entrySet().stream().map(Map.Entry::getKey).forEach(System.out::println);
        map.entrySet().stream().map(Map.Entry::getValue).forEach(System.out::println);
        System.out.println("---------------------");

        map.entrySet().stream().filter(me->me.getKey()>30).map(Map.Entry::getValue).forEach(System.out::println);
    }
}
