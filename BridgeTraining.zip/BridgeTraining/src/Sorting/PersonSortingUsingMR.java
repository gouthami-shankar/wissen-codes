package Sorting;

import java.util.Comparator;
import java.util.TreeSet;

public class PersonSortingUsingMR {
    public static void main(String[] args) {
        TreeSet<Person> personTreeSet= new TreeSet<>(Comparator.comparing(Person::getAge,Comparator.reverseOrder()));
        personTreeSet.add(new Person(10,"Gouthami",25));
        personTreeSet.add(new Person(8,"Siri",23));
        personTreeSet.add(new Person(9,"Darshan",28));
        personTreeSet.add(new Person(1,"Neethu",21));
        personTreeSet.add(new Person(6,"Ashwin",29));

        for(Person person:personTreeSet){
            System.out.println(person);
        }
    }
    private static void compareDescending() {

    }



}
