interface Intr
{
    public default void abc()
    {
        System.out.println("HI from I interface abc() method");
    }
}
interface Jntr
{
    public default void abc()
    {
        System.out.println("HELLO from J interface abc() method");
    }
}
class Aa implements Intr, Jntr
{
    public void abc()
    {
        System.out.println("My own logic");
        Intr.super.abc();
        Jntr.super.abc();
    }
}

class DiamondProblem
{
    public static void main(String args[])
    {
        Aa a1 = new Aa();
        a1.abc();
    }
}
