interface I{
    public void abc();
}

interface J{
    public A greet(String n);
}

class A{
    //init method--> is always called from the class is called
    {
        System.out.println("Hello from init block");
    }
    public A(){
        System.out.println("From A() constructor");
    }
    public A(String name){
        System.out.println("Welcome!! "+name);
    }
    public void demo(){
        System.out.println("This is from instance method demo()");
    }
    public static void test(){
        System.out.println("This is from static method test()");
    }
    public A(int x){
        System.out.println("From A(x) construction");
    }
    static{
        System.out.println("Hello from static block");
    }
}


public class MethodReference {
    public static void main(String[] args) {
        I i= A::test;
        i.abc();

        I i1= new A()::demo;
        i1.abc();

        I i2= A::new;
        i2.abc();

        J j1= A::new;
        A a1=j1.greet("hi");
        A a2=j1.greet("hello");
        A a3=j1.greet("hiiii");
        System.out.println(a1);
        System.out.println(a2);
        System.out.println(a3);


    }
}
