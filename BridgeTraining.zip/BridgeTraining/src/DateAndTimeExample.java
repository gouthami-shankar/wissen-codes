import java.time.*;
import java.util.Set;

public class DateAndTimeExample {
    public static void main(String[] args) {
        /*
		Date d1 = new Date();
		System.out.println(d1);

		d1.setMonth(45);
		System.out.println(d1);

		d1.setTime(-924323232l);
		System.out.println(d1);
		*/
        //LocalDate d1= LocalDate.now();
        LocalDate d1= LocalDate.of(1983, Month.MAY,17);
        System.out.println(d1);

        LocalTime t1= LocalTime.now();
        System.out.println(t1);

        LocalDateTime dt1= LocalDateTime.now();
        System.out.println(dt1);

        LocalTime t2= LocalTime.now(ZoneId.of("Singapore"));
        System.out.println(t2);
        LocalTime t3= LocalTime.now(ZoneId.of("Egypt"));
        System.out.println(t3);
        LocalTime t4= LocalTime.now(ZoneId.of("America/New_York"));
        System.out.println(t4);

        Set s= ZoneId.getAvailableZoneIds();
        s.forEach(System.out::println);

        System.out.println(d1.plusMonths(6));
        System.out.println(d1.minusMonths(6));
    }
}
