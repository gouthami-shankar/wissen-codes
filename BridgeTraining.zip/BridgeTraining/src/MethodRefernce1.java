public class MethodRefernce1 {
    public static void main(String args[]) throws Exception {
        // Runnable r1 = Ant::Test;
        Thread t1 = new Thread(Ant::Test);
        Thread t2 = new Thread(new Ant()::demo);
        Thread t3 = new Thread(Ant::new);
        t1.start();
        t2.start();
        t3.start();
    }
}

class Ant {
    {
        System.out.println("init block");
    }
    public Ant() {
        for (int i = 0; i < 20; i++)
            System.out.println("from A() constructor" + 1);
    }
    public static void Test() {
        for (int i = 0; i < 20; i++)
            System.out.println("static method test" + i);
    }
    public void demo() {
        for (int i = 0; i < 20; i++)
            System.out.println("this is from an instace methode demo" + i);
    }
}
