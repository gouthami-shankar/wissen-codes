import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

class Cons implements Consumer<Integer>{
    @Override
    public void accept(Integer integer) {
        System.out.println("Class Cons: "+integer);
    }
}

class ConsumerInterfaceExample{
    static void printMessage(String name){
        System.out.println("From printMessage: "+name);
    }
    static void printValue(int value){
        System.out.println("From printValue: "+value);
    }
}

public class ConsumerExample {
    public static void main(String[] args) {
        List<Integer> list= Arrays.asList(11,22,33,44,55,66,77);
        list.forEach(new Cons());

        Consumer<String> c1= ConsumerInterfaceExample::printMessage;
        c1.accept("Gouthami");

        Consumer<Integer> c2= ConsumerInterfaceExample::printValue;
        c2.accept(99);

        System.out.println("----------------");
        list.forEach(c2);
    }
}
