import javax.crypto.spec.PSource;
import java.util.function.Predicate;

public class PredicateExample {
    public static void main(String[] args) {
        int arr[]={11,22,33,44,55,66,77,88,99};
        Predicate<Integer> p1= (x)->(x%2)==0;
        Predicate<Integer>p2=(x)->x>50;
        process(p1,arr);
        process(p1.negate(),arr);
        process(p2,arr);
        process(p2.negate(),arr);
        process(p2.and(p1),arr);
        process(p2.and(p1.negate()),arr);
        process(p2.negate().or(p1),arr);
        process(p2.negate().or(p1.negate()),arr);

    }

    private static void process(Predicate<Integer> p, int[] arr) {
        for(int i=0;i<arr.length;i++){
            if(p.test(arr[i])){
                System.out.println(arr[i]);
            }
        }
        System.out.println("----------");
    }
}
