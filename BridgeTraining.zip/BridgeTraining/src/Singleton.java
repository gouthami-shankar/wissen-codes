class Parent {
    private static int countParnent = 0;
    private static Parent parent = null;
    private static int countChild = 0;

    protected Parent() {
        if (this instanceof Parent && countParnent == 0 && !(this instanceof Child)) {
            System.out.println("A object created.....");
            countParnent++;
        } else if (this instanceof Child && countChild == 0) {
            System.out.println("B object created.....");
            countChild++;
        } else
            throw new RuntimeException("Object already exist");
    }

    public static Parent getParent() {
        if (countParnent == 0)
            parent = new Parent();
        return parent;
    }
}

class Child extends Parent {
    private static Child child = null;

    private Child() {
    }

    public static Child getChild() {
        if (child == null)
            child = new Child();
        return child;
    }
}

public class Singleton {
    public static void main(String args[]) {
        Parent a1 = Parent.getParent();
        Parent a2 = Parent.getParent();
        Child b1 = Child.getChild();
        Child b2 = Child.getChild();

        System.out.println(a1 == a2);
        System.out.println(b1 == b2);
    }
}
