import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class EmployeeC {
    private String empName;
    private int age;
    private double salary;
    private String designation;
    private String department;

    public EmployeeC() {
    }

    public EmployeeC(String empName, int age, double salary, String designation, String department) {
        this.empName = empName;
        this.age = age;
        this.salary = salary;
        this.designation = designation;
        this.department = department;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "EmployeeC{" + "empName='" + empName + '\'' + ", age=" + age + ", salary=" + salary + ", designation='" + designation + '\'' + ", department='" + department + '\'' + '}';
    }
}

public class Java8Advanced {
    public static void main(String[] args) {
        List<EmployeeC> list = new ArrayList<>();
        list.add(new EmployeeC("Ganesh", 21, 25000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Geetha", 25, 35000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Suresh", 28, 25000, "Manager", "IT and Consulting Department"));
        list.add(new EmployeeC("Shanvi", 24, 45000, "Manager", "HR Department"));
        list.add(new EmployeeC("Swathi", 32, 22000, "Tester", "Validation Department"));
        list.add(new EmployeeC("Ramesh", 35, 35000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Brijesh", 41, 45000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Priya", 51, 28000, "Manager", "HR Department"));
        list.add(new EmployeeC("Hima", 21, 27000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Monish", 37, 73000, "Tester", "Validation Department"));
        list.add(new EmployeeC("Kiran", 26, 65000, "Manager", "HR Department"));
        list.add(new EmployeeC("Nagesh", 36, 75000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Meghana", 39, 80000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Deepti", 48, 29000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Kavya", 45, 55000, "Tester", "Validation Department"));
        list.add(new EmployeeC("Abhi", 33, 24000, "Manager", "HR Department"));
        list.add(new EmployeeC("Nandish", 56, 66000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Pradeep", 33, 44000, "Programmer", "IT and Consulting Department"));
        list.add(new EmployeeC("Prasanna", 31, 35000, "Programmer", "IT and Consulting Department"));

        System.out.println("Total Strength department wise");
        Map<String, Long> strengthDepartmentWise = list.stream().collect(Collectors.groupingBy(e -> e.getDepartment(), Collectors.counting()));
        System.out.println(strengthDepartmentWise);
        System.out.println("---------------------------------------------");

        System.out.println("3 Senior Employee");
        /* Using inbuilt Comparator
        List<EmployeeC> seniorEmployees= list.stream().sorted(Comparator.comparingInt(EmployeeC::getAge).reversed()).limit(3).collect(Collectors.toList());
         */
        List<EmployeeC> seniorEmployees= list.stream().sorted((e1,e2)->e2.getAge()-e1.getAge()).limit(3).collect(Collectors.toList());
        System.out.println(seniorEmployees);
        System.out.println("---------------------------------------------");

        System.out.println("Type of Company");
        Map<String, Long> ageMap = new HashMap<>();
        ageMap.put("YOUTH", list.stream().filter(e -> e.getAge() <= 30).collect(Collectors.counting()));
        ageMap.put("MID_AGE", list.stream().filter(e -> e.getAge() > 30 && e.getAge() <= 40).collect(Collectors.counting()));
        ageMap.put("SENIOR", list.stream().filter(e -> e.getAge() > 40).collect(Collectors.counting()));
        String typeOfCompany = ageMap.entrySet().stream().max((e1, e2) -> (int) (e1.getValue()-e2.getValue())).get().getKey();
        System.out.println(typeOfCompany);
        System.out.println();
        System.out.println("****** Optimised way ******");
        Function<EmployeeC,String> getTypeOfCompany= e->e.getAge()<=30?"YOUTH":(e.getAge()>30 &&e.getAge()<=40?"MID_AGE":"SENIOR");
        Map<String,Long> groupAndCountCompany=list.stream().collect(Collectors.groupingBy(getTypeOfCompany,Collectors.counting()));
        String companyType=groupAndCountCompany.entrySet().stream().max((e1,e2)-> (int) (e1.getValue()-e2.getValue())).get().getKey();
        System.out.println(companyType);
        System.out.println("---------------------------------------------");

        System.out.println("5th Highest earning employee");
        EmployeeC HighestEarned5th = list.stream().sorted((e1,e2)-> (int) (e2.getSalary()-e1.getSalary())).skip(4).findFirst().orElseThrow(() -> new NullPointerException());
        System.out.println(HighestEarned5th);
        System.out.println("---------------------------------------------");

        System.out.println("Expensive Department");
        Map.Entry<String, Integer> expensiveDepartment = list.stream().collect(Collectors.groupingBy(e -> e.getDepartment(), Collectors.summingInt(e -> (int) e.getSalary()))).entrySet().stream().collect(Collectors.maxBy(Comparator.comparing(e -> e.getValue()))).orElseThrow(() -> new NullPointerException());
        System.out.println(expensiveDepartment);
        System.out.println("---------------------------------------------");

    }
}
