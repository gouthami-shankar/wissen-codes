import java.io.*;
import javax.script.*;
public class NashornDemo {
    public static void main(String args[]){
        try{
            ScriptEngineManager mgr= new ScriptEngineManager();
            ScriptEngine engine= mgr.getEngineByName("JavaScript");

            //engine.eval("print('Hello from Java program written in javascript lang')");
            //engine.eval(new FileReader("abc.js"));
            engine.eval(new FileReader("C:\\Users\\User\\Documents\\IntelliJ Workspace\\BridgeTraining\\src\\xyz.js"));

            Invocable inv=(Invocable)engine;
            inv.invokeFunction("demo");
            inv.invokeFunction("addNum",11,22);
            String result=(String) inv.invokeFunction("greet","Gouthami","Shankar");
            System.out.println(result);
        }catch(Exception e){
            System.out.println(e);
        }
    }
}
