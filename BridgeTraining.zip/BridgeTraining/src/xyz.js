function demo(){
	print('Just for demo');
}

function addNum(a,b){
	var c=a+b;
	print("The sum of "+a+" and "+b+" is : "+c);
}

function greet(fname,lname){
	var fullName= fname+" "+lname;
	return "Welcome ! "+fullName
}