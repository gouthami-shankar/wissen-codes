import javax.sound.midi.Soundbank;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StreamExample {
    public static void main(String[] args) {
        List<Integer> l1= Arrays.asList(1,2,3);
        List<Integer> l2= Arrays.asList(4,5,6,7);
        List<Integer> l3= Arrays.asList(8,9,10);

        //FlatMap
        List<List<Integer>> list= Arrays.asList(l1,l2,l3);
        System.out.println(list);
        List<Integer> result= list.stream().flatMap(lst->lst.stream()).map(x->x+x).collect(Collectors.toList());
        System.out.println(result);

        Predicate<Integer> p1= (x)->x%2==0;
        List<Integer>l=l1.stream().filter(p1).collect(Collectors.toList());
        System.out.println(l);

        IntStream.range(1,10).forEach(System.out::println);
        IntStream.rangeClosed(91,100).forEach(System.out::println);
        OptionalInt ans=IntStream.rangeClosed(1,2).reduce((a, b)->a+b);
        System.out.println(ans.getAsInt());

           /*parallel stream works
        1,10-->11
        2,10-->12
        3,10-->13

        11,12-->23
        23,13-->36
        */
        int res= Arrays.asList(1,2,3).parallelStream().reduce(10,(a,b)->a+b,(a,b)->a+b);
        System.out.println(res);

        IntSummaryStatistics statistics= IntStream.rangeClosed(1,10).summaryStatistics();
        System.out.println(statistics);
        System.out.println("Min: "+statistics.getMin());
        System.out.println("Max: "+statistics.getMax());
        System.out.println("Total Sum: "+statistics.getSum());
        System.out.println("Total count: "+statistics.getCount());
        System.out.println("Average: "+statistics.getAverage());





    }
}
