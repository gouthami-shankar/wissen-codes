class AThread implements Runnable{
    //By default it is object level locaking
   /* public synchronized void run(){
        for(int i=1;i<=20;i++){
            System.out.println(Thread.currentThread().getName()+" : "+i);
            try{
                Thread.sleep(500);
            }catch (Exception e){
                System.out.println(e);
            }
        }
    }*/

    public void run(){
        System.out.println(Thread.currentThread().getName()+" is waiting to acquire lock");
        synchronized (this) {
            System.out.println(Thread.currentThread().getName()+" has got the key and entered the block");
            for (int i = 1; i <= 20; i++) {
                System.out.println(Thread.currentThread().getName() + " : " + i);
                try {
                    Thread.sleep(500);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }
}

public class Syncronization {
    AThread a1= new AThread();
    Thread t1= new Thread(a1);
    Thread t2= new Thread(a1);
    Thread t3= new Thread(a1);


}
