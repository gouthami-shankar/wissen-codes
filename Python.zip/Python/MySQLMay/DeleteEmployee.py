import mysql.connector;

conn = mysql.connector.connect(host='localhost', database='may2023', user='root', password='Welcome123')

def delete(id):
    if conn.is_connected():
     print("Connection Established Successfully")
     cursor = conn.cursor()
     str = "delete from emp where id='%d'"
     args=(id)
     try:
        cursor.execute(str % args)
        conn.commit()
        print('Employee deleted Successfully')
     except:
        conn.rollback()
     finally:
        cursor.close()
        conn.close()

empID = int(input('Enter the Employee ID: '))
delete(empID)