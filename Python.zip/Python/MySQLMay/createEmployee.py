import mysql.connector;
conn=mysql.connector.connect(host='localhost',database='may2023',user='root',password='Welcome123')

if conn.is_connected():
    print("Connection Established successfully")

cursor= conn.cursor()

try:
    cursor.execute("insert into emp values(104,'Tushar',580000)")
    conn.commit()
    print('Employee Added Successfully')

except:
    conn.rollback()

cursor.close()
conn.close()

