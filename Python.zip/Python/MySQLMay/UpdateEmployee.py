import mysql.connector;

# Connection Establishment

conn = mysql.connector.connect(host='localhost',database='may2023',user='root',password='Welcome123')

if conn.is_connected():
    print("Connection Established Successfully")\

cursor = conn.cursor()
cursor.execute("select * from emp")
row = cursor.fetchall()
print(row)

sql = "UPDATE emp SET name = 'Gouthami' WHERE name ='Kalpana'"
cursor.execute(sql)
conn.commit()
print(cursor.rowcount, "records effected")

cursor.close()
conn.close()