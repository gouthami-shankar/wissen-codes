import mysql.connector;

# Connection Establishment

conn = mysql.connector.connect(host='localhost',database='may2023',user='root',password='Welcome123')

if conn.is_connected():
    print("Connection Established Successfully")

# Fetch ONE

cursor = conn.cursor()

cursor.execute('select * from emp')

row = cursor.fetchone()

while row is not None:
    print(row)
    row=cursor.fetchone()

cursor.close()
conn.close()

