import pickle,Employee

f = open("employee.dat","wb") # wb ---> write binary
e = Employee.Employee(101,"Ramya Shankar",99)
pickle.dump(e,f)
f.close()