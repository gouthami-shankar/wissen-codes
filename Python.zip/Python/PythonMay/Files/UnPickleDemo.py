import pickle
f = open("employee.dat","rb") # rb read binary
x = pickle.load(f)
x.display()
f.close()