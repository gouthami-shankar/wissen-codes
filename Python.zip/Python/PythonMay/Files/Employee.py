class Employee:
    def __init__(self,id,name,score):
        self.id=id
        self.name=name
        self.score=score

    def display(self):
        print(self.id,self.name,self.score)

# Serialization ---> It converts Stream Code to Byte Code ( Pickle )
# De-Serialization ---> It converts Byte Code to Stream Code ( UnPickle)