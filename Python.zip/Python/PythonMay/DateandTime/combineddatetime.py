from datetime import *

d = date(2023,5,18)
t = time(1,40)
dt = datetime.combine(d,t)
print(dt)