from datetime import *

def validateCard(expDate):
    if expDate>datetime.now().date():
        print('Card is Valid')
    else:
        print('Card is Expired')

validateCard(date(2023,5,19))