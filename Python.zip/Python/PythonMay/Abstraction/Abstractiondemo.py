from abc import abstractmethod, ABC

class BMW(ABC):
    def __init__(self, model, year):
        self.model=model
        self.year=year
    @abstractmethod
    def start(self):
        pass

    @abstractmethod
    def stop(self):
        pass

class ThreeSeries(BMW):
    def __init__(self,cruisecontrolenabled, model, year):
        # BMW.__init__(self, model, year)
        super().__init__(model, year)
        self.cruisecontrolenabled=cruisecontrolenabled

    def display(self):
        print(self.cruisecontrolenabled)

    def start(self):
        super().start()
        print("Starting the Car")

    def stop(self):
        super().stop()
        print("Stopping the Car")

bmw = ThreeSeries(True, "BMW1", 2023)
print(bmw.cruisecontrolenabled)
print(bmw.model)
print(bmw.year)
bmw.start()
bmw.stop()

bmw.display()