import logging

logging.basicConfig(filename="sample.log",level=logging.DEBUG)

try:
    f=open("testfile","w") #w--> write mode
    a,b=[int(x) for x in input("Enter 2 numbers ").split()]
    logging.info("Division in progress")
    c=a/b
    f.write("Writing" %c)
except ZeroDivisionError:
    print("Division by zero allowed")
    print("Plase enter the non zero number ")
    logging.error("Division by zero")

else:
    print("You have entered a non zero number")

finally:
    f.close()
    print("File is closed")

