import logging

logging.basicConfig(filename="sample.log",level=logging.DEBUG)
logging.critical("Critical")
logging.error("Error")
logging.info("Info")
logging.debug("Debug")