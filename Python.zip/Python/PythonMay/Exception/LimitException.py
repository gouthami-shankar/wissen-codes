class LimitException(Exception):
    def __init__(self, msg):
        self.msg=msg

def withdrawal(amt):
    if(amt>75000):
        raise LimitException("Cannot withdraw > 75000")

withdrawal(7000)
print("Withraw")