class BMW():
    def __init__(self, model, year):
        self.model=model
        self.year=year

    def start(self):
        print("Starting the Car")

    def stop(self):
        print("Stopping the Car")

class ThreeSeries(BMW):
    def __init__(self,cruisecontrolenabled, model, year):
        # BMW.__init__(self, model, year)
        super().__init__(model, year)
        self.cruisecontrolenabled=cruisecontrolenabled

    def display(self):
        super().start()
        super().stop()
        print(self.cruisecontrolenabled)

bmw = ThreeSeries(True, "BMW1", 2023)
print(bmw.cruisecontrolenabled)
print(bmw.model)
print(bmw.year)
# bmw.start()
# bmw.stop()

bmw.display()