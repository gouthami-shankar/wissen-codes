class Product:
    #constructor
    def __int__(self):
        self.name='Nokia'
        self.description='It is a mobile'
        self.price=40000

    #Parameterized Constructor
    def __init__(self,id,rating):
        self.id=id
        self.rating=rating

    #Destructor
    def __del__(self):
        print("Destructor is called")
    #Method
    def display(self):
        print(self.name)
        print(self.description)
        print(self.price)

#p1=Product() #default constructor
#p1.display()

p2 = Product(101,[9,7,8,6,9]) # Parameterized Constructor
print(p2.id)
print(p2.rating)