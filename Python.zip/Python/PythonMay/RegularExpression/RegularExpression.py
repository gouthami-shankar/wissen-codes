import re

str = "Think One 17-05-2023. One idea idea 79 One at a Time 18-05-2023"

result = re.search(r'O\w', str)
print(result.group())

result = re.search(r'O\w\w', str)
print(result.group())

result = re.findall(r'O\w\w', str)
print(result)

result = re.match(r'T\w', str)  # match starting of the String
print(result.group())

result = re.sub(r'One', 'Three', str)
print(result)

result = re.findall(r'O\w{1,2}', str)
print(result)

result = re.split(r'\d+', str)
print(result)

result = re.findall(r'\d{1,2}-\d{1,2}-\d{4}', str)
print(result)

result = re.search(r'^T\w*', str)
print(result.group())

# ^ ---> should present at the beginning of the String. Otherwise, it returns "None"